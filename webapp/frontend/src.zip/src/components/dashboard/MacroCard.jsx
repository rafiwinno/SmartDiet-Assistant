import ProgressBar from "../ui/ProgressBar";

const MACRO_CONFIG = {
  protein: {
    label: "Protein",
    unit: "g",
    color: "#ea580c",
    border: "border-t-orange-500",
  },
  carbs: {
    label: "Karbo",
    unit: "g",
    color: "#d97706",
    border: "border-t-amber-500",
  },
  fat: {
    label: "Lemak",
    unit: "g",
    color: "#2563eb",
    border: "border-t-blue-500",
  },
};

export default function MacroCard({
  type = "protein",
  consumed = 0,
  target = 100,
}) {
  const { label, unit, color, border } = MACRO_CONFIG[type];
  const pct = Math.min(Math.round((consumed / target) * 100), 100);

  return (
    <div
      className={`bg-white rounded-xl shadow-sm border border-stone-200 border-t-4 ${border} p-4`}
    >
      <p className="text-xs font-medium text-stone-400 mb-3">{label}</p>
      <p className="text-2xl font-semibold text-stone-800 leading-none">
        {consumed}
        <span className="text-sm font-normal text-stone-400 ml-1">{unit}</span>
      </p>
      <p className="text-xs text-stone-400 mt-1">
        Target {target}
        {unit}
      </p>
      <ProgressBar
        value={consumed}
        max={target}
        color={color}
        className="mt-3"
      />
      <p className="text-xs text-stone-400 mt-1.5 text-right">{pct}%</p>
    </div>
  );
}
