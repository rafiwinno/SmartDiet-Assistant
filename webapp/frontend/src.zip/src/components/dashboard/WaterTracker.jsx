import Card from "../ui/Card";
import Button from "../ui/Button";
import ProgressBar from "../ui/ProgressBar";

export default function WaterTracker({ glasses = 0, target = 8, onAdd }) {
  return (
    <Card>
      <div className="flex items-center justify-between mb-3">
        <div>
          <p className="text-sm font-semibold text-stone-800">Asupan air</p>
          <p className="text-xs text-stone-400 mt-0.5">
            {glasses} dari {target} gelas ·{" "}
            {Math.round((glasses / target) * 100)}%
          </p>
        </div>
        <Button
          variant="secondary"
          size="sm"
          className="text-blue-600 bg-blue-50 border-blue-200 hover:bg-blue-100"
          onClick={onAdd}
        >
          + Tambah
        </Button>
      </div>

      <div className="flex gap-1.5 mt-3 flex-wrap">
        {Array.from({ length: target }).map((_, i) => (
          <div
            key={i}
            className={`flex-1 min-w-6 h-7 rounded-md flex items-center justify-center text-xs font-bold transition-all
            ${i < glasses ? "bg-blue-500 text-white" : "bg-stone-100 text-stone-300"}`}
          >
            {i < glasses ? "●" : "○"}
          </div>
        ))}
      </div>

      <ProgressBar
        value={glasses}
        max={target}
        color="#3b82f6"
        className="mt-3"
      />
    </Card>
  );
}
